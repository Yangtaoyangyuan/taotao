package com.yt.common.pojo;

import java.util.List;

public class EUDateGridResult {
	//total为查询到的总的数量
	private long total;
	//rows是一个pojo列表
	private List<?> rows;
	public long getTotal() {
		return total;
	}
	public void setTotal(long total) {
		this.total = total;
	}
	public List<?> getRows() {
		return rows;
	}
	public void setRows(List<?> rows) {
		this.rows = rows;
	}
	
}
