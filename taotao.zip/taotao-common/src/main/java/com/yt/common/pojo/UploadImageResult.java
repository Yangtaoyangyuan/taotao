package com.yt.common.pojo;

public class UploadImageResult {
	private int error;
	private String url;
	private String massage;
	
	public String getMassage() {
		return massage;
	}
	public void setMassage(String massage) {
		this.massage = massage;
	}
	public int getError() {
		return error;
	}
	public void setError(int error) {
		this.error = error;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	@Override
	public String toString() {
		return "UploadImageResult [error=" + error + ", url=" + url + ", massage=" + massage + "]";
	}
	
	
	
	
}
