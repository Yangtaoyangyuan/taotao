package com.yt.service;

public interface ItemParamItemService {

	//根据商品id查询商品的规格参数，返回显示
	String getItemParamItemService(long itemId);
}
