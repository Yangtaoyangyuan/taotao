package com.yt.service.Impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yt.common.Utils.JsonUtils;
import com.yt.mapper.TbItemParamItemMapper;
import com.yt.pojo.TbItemParamItem;
import com.yt.pojo.TbItemParamItemExample;
import com.yt.pojo.TbItemParamItemExample.Criteria;
import com.yt.service.ItemParamItemService;

@Service
public class itemParamItemServiceImpl implements ItemParamItemService {

	@Autowired
	private TbItemParamItemMapper itemParamItemMapper;
	
	/**
	 * 根据商品分类id,从商品规格参数信息数据库中获取某个商品的参数信息
	 */
	@Override
	public String getItemParamItemService(long itemId) {
		//根据商品id查询商品规格参数信息
		TbItemParamItemExample example = new TbItemParamItemExample();
		Criteria criteria = example.createCriteria();
		criteria.andItemIdEqualTo(itemId);
		List<TbItemParamItem> list = itemParamItemMapper.selectByExampleWithBLOBs(example);
		if(list == null || list.size() == 0){
			return null;
		}
		TbItemParamItem itemParamItem = list.get(0);
		String paramData = itemParamItem.getParamData();
		
		//返回HTML
		//把规格参数json数据转换成java对象
		List<Map> jsonToList = JsonUtils.jsonToList(paramData, Map.class);
		StringBuffer sb = new StringBuffer();
		
		sb.append("<table cellpadding=\"0\" cellspacing=\"1\" width=\"100%\" border=\"1\" class=\"Ptable\">\n");
		sb.append("    <tbody>\n");
		for(Map map:jsonToList){
			sb.append("    <tr>\n");
			sb.append("        <th class=\"tdTitle\" colspan=\"2\">"+map.get("group")+"</th>\n");
			sb.append("    </tr>\n");
			List<Map> list2 = (List<Map>) map.get("params");
			for(Map map2:list2){
				sb.append("    <tr>\n");
				sb.append("        <td class=\"tdTitle\">"+map2.get("k")+"</td>\n");
				sb.append("        <td>"+map2.get("v")+"</td>\n");
				sb.append("    </tr>\n");
			}
		}
		sb.append("    </tbody>\n");
		sb.append("</table>");
		
		return sb.toString();
	}

}
