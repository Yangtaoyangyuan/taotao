package com.yt.service.Impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yt.common.Utils.IDUtils;
import com.yt.common.Utils.TaotaoResult;
import com.yt.common.pojo.EUDateGridResult;
import com.yt.mapper.TbItemDescMapper;
import com.yt.mapper.TbItemMapper;
import com.yt.mapper.TbItemParamItemMapper;
import com.yt.pojo.TbItem;
import com.yt.pojo.TbItemDesc;
import com.yt.pojo.TbItemExample;
import com.yt.pojo.TbItemExample.Criteria;
import com.yt.pojo.TbItemParamItem;
import com.yt.service.ItemService;

@Service
public class ItemServiceImpl implements ItemService {
	
	@Autowired
	private TbItemMapper itemMapper;
	
	@Autowired
	private TbItemDescMapper itemDescMapper;
	
	@Autowired
	private TbItemParamItemMapper itemParamItemMapper;

	/**
	 * 根据商品id查询商品
	 */
	@Override
	public TbItem getItemById(long ItemId) {

		//return itemMapper.selectByPrimaryKey(ItemId);
		
		TbItemExample example = new TbItemExample();
		//添加查询条件（不加条件默认查询所有）
		Criteria criteria = example.createCriteria();
		criteria.andIdEqualTo(ItemId);
		//根据id查询信息
		List<TbItem> list = itemMapper.selectByExample(example);
		if(list != null && list.size()>0){
			return list.get(0);
		}
		return null;
	}

	/**
	 * 查询商品信息，并分页显示
	 */
	@Override
	public EUDateGridResult getItemList(int page,int rows) {
		TbItemExample example = new TbItemExample();
		
		PageHelper.startPage(page, rows);
		List<TbItem> list = itemMapper.selectByExample(example);
		PageInfo<TbItem> pageInfo = new PageInfo<TbItem>(list);
		long total = pageInfo.getTotal();
		
		EUDateGridResult dateGridResult = new EUDateGridResult();
		dateGridResult.setTotal(total);
		dateGridResult.setRows(list);
		
		return dateGridResult;
	}

	/**
	 * 添加商品，包括添加商品到商品数据库，
	 * 添加富文本框中的商品描述到商品描述数据库中，
	 * 添加商品的规格参数信息到商品规格参数数据库中
	 */
	@Override
	public TaotaoResult createItem(TbItem item,String desc, String itemParams) throws Exception {
		//补全Item信息
		//生成ID
		Long itemId = IDUtils.getItemId();
		item.setId(itemId);
		//设置商品的状态status
		item.setStatus((byte)1);
		//设置商品的创建时间和更新时间
		item.setCreated(new Date());
		item.setUpdated(new Date());
		
		//将商品插入商品数据库
		itemMapper.insert(item);
		
		//将商品描述信息插入商品描述信息数据库(调用下面的私有函数来完成)
		TaotaoResult result = insertItemDesc(itemId, desc);
		if(result.getStatus() != 200){
			throw new Exception();
		}
		//将商品的规格参数添加到商品规格参数表中（通过调用下面的私有函数来完成）
		result = insertItemParamItem(itemId, itemParams);
		if(result.getStatus() != 200){
			throw new Exception();
		}
		return TaotaoResult.ok();
	}
	
	/**
	 * 添加商品描述信息,即在添加商品时，将富文本编辑器中的商品描述信息存到商品描述表单中
	 * @param itemId
	 * @param desc
	 * @return
	 */
	private TaotaoResult insertItemDesc(Long itemId, String desc){
		//商品描述信息包括id、描述文本、创建时间、更新时间，利用逆向工程生成的pojo进行封装
		TbItemDesc itemDesc = new TbItemDesc();
		itemDesc.setItemId(itemId);
		itemDesc.setItemDesc(desc);
		itemDesc.setCreated(new Date());
		itemDesc.setUpdated(new Date());
		//插入数据库
		itemDescMapper.insert(itemDesc);
		return TaotaoResult.ok();
	}
	
	/**
	 * 在添加商品时，将商品的规格参数信息保存到商品规格参数表单中
	 * @param itemId
	 * @param itemParams
	 * @return
	 */
	private TaotaoResult insertItemParamItem(long itemId, String itemParams){
		TbItemParamItem itemParamItem = new TbItemParamItem();
		itemParamItem.setItemId(itemId);
		itemParamItem.setParamData(itemParams);
		itemParamItem.setCreated(new Date());
		itemParamItem.setUpdated(new Date());
		
		itemParamItemMapper.insert(itemParamItem);
		return TaotaoResult.ok();
	}
	
	


}
