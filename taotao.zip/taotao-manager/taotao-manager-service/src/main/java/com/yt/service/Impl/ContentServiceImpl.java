package com.yt.service.Impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yt.common.Utils.HttpClientUtil;
import com.yt.common.Utils.TaotaoResult;
import com.yt.common.pojo.EUDateGridResult;
import com.yt.mapper.TbContentMapper;
import com.yt.pojo.TbContent;
import com.yt.pojo.TbContentExample;
import com.yt.pojo.TbContentExample.Criteria;
import com.yt.service.ContentService;

/**
 * 根据内容分类管理的某类广告id去内容管理数据库中查询相应广告信息，并返回分页显示
 * @param CtaegoryId 某类广告的id
 * @param page 多少页
 * @param rows 每页多少条信息
 * @return EUDateGridResult
 */
@Service
public class ContentServiceImpl implements ContentService {

	@Autowired
	private TbContentMapper contentMapper; 
	
	//注入缓存同步所需要的url
	@Value("${REST_BASE_URL}")
	private String REST_BASE_URL;
	
	@Value("${REST_CONTENT_REDIS_SYNC_URL}")
	private String REST_CONTENT_REDIS_SYNC_URL;
	
	/**
	 * 点击内容分类管理时，根据内容分类id查询数据库，并分页返回显示
	 * @param categoryId  内容分类id
	 * @param page 页数
	 * @param rows 每页多少条数据
	 * @return 返回一个自定义的pojo对象（EUDateGridResult），
	 * 该对象有两个属性，分别为总的查询到的数据个数，已经查询到的所有数据的list集合对象
	 */
	@Override
	public EUDateGridResult getContent(long categoryId, int page, int rows) {
		TbContentExample example = new TbContentExample();
		Criteria criteria = example.createCriteria();
		criteria.andCategoryIdEqualTo(categoryId);
		
		//查询之前利用PageHelper对其进行拦截，做分页处理
		PageHelper.startPage(page, rows);
		List<TbContent> list = contentMapper.selectByExample(example);
		//获取总的数量
		PageInfo<TbContent> pageInfo = new PageInfo<TbContent>(list);
		long total = pageInfo.getTotal();
		
		EUDateGridResult dateGridResult = new EUDateGridResult();
		dateGridResult.setRows(list);
		dateGridResult.setTotal(total);
		
		return dateGridResult;
	}

	/**
	 * 向内容管理数据库中新增一条广告信息
	 * @param tbContent  广告信息对象（一个pojo）
	 * @param desc 广告信息对象的富文本编辑器中的描述信息
	 * @return 返回一个TaotaoResult
	 */
	@Override
	public TaotaoResult insertContent(TbContent tbContent) {
		//补全TbContent信息
		tbContent.setCreated(new Date());
		tbContent.setUpdated(new Date());
		
		contentMapper.insert(tbContent);
		
		//添加缓存同步
		try {
			HttpClientUtil.doGet(REST_BASE_URL + REST_CONTENT_REDIS_SYNC_URL + tbContent.getCategoryId());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return TaotaoResult.ok();
	}

}
