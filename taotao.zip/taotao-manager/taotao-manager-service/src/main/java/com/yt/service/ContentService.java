package com.yt.service;

import com.yt.common.Utils.TaotaoResult;
import com.yt.common.pojo.EUDateGridResult;
import com.yt.pojo.TbContent;

public interface ContentService {
	/**
	 * 根据内容分类管理的某类广告id去内容管理数据库中查询相应广告信息，并返回分页显示
	 * @param CtaegoryId 某类广告的id
	 * @param page 多少页
	 * @param rows 每页多少条信息
	 * @return EUDateGridResult
	 */
	EUDateGridResult getContent(long categoryId, int page, int rows);
	
	/**
	 * 向内容管理数据库中新增一条广告信息
	 * @param tbContent  广告信息对象（一个pojo）
	 * @param desc 广告信息对象的富文本编辑器中的描述信息
	 * @return 返回一个TaotaoResult
	 */
	TaotaoResult insertContent(TbContent tbContent);
}
