package com.yt.service;

import com.yt.common.Utils.TaotaoResult;
import com.yt.pojo.TbItemParam;

public interface ItemParamService {
	//根据商品类别id查询数据库中是否有该类商品的规格参数信息模板，有的话则返回模板，否则返回null 
	TaotaoResult getItemParamByCid(long cid);
	
	//若某类商品的规格参数模板在规格参数模板数据库中不存在，则加入该类商品的规格参数模板
	TaotaoResult insertItemParam(TbItemParam itemParam);
	

}
