package com.yt.service;

import org.springframework.web.multipart.MultipartFile;

import com.mysql.jdbc.UpdatableResultSet;
import com.yt.common.pojo.UploadImageResult;

public interface ImageService {
	
	public UploadImageResult UploadImage(MultipartFile uploadFile);

}
