package com.yt.service.Impl;

import java.io.IOException;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.yt.common.Utils.FtpUtil;
import com.yt.common.Utils.IDUtils;
import com.yt.common.pojo.UploadImageResult;
import com.yt.service.ImageService;

@Service
public class ImageServiceImpl implements ImageService{
	//注入FTP服务器的参数
	@Value("${FTP_ADDRESS}")
	private String host;
	@Value("${FTP_PROT}")
	private int port;
	@Value("${FTP_USERNAME}")
	private String username;
	@Value("${FTP_PASSWORD}")
	private String password;
	@Value("${FTP_BASEPATH}")
	private String basepath;
	
	//注入图片服务器的URL参数
	@Value("${IMAGE_BASE_URL}")
	private String image_base_url;

	@Override
	public UploadImageResult UploadImage(MultipartFile uploadFile){
		
		UploadImageResult uploadImageResult = new UploadImageResult();
		
		try {
			//生成一个新的文件名（服务器端存储的名字）
			//取文件的原始文件名
			String oldName = uploadFile.getOriginalFilename();
			//生成新文件名
//		可以用UUID.randomUUID()来生成随机数在加上原始文件名;
			//也可以用当前时间加上三位随机数来组成文件名（在工具类中实现了）
			IDUtils idUtils = new IDUtils();
			String newName = idUtils.getImageName();
			//将新的文件名与原始文件名的扩展名组合成新的文件名（扩展名即为文件格式，如jpg\png等）
			newName = newName + oldName.substring(oldName.lastIndexOf("."));
			
			//图片上传
			FtpUtil ftpUtil = new FtpUtil();
//		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
//		String dateString = dateFormat.format(new Date());
			//上面的操作可由joda包里的模块完成
			String filepath = new DateTime().toString("yyyy-MM-dd");
			
			//这里的host,port,username,password,basename这些关于图片服务器的值不能写死这这，而是需要写在配置文件中，通过读取配置文件来进行注入
			boolean result = ftpUtil.uploadFile(host, port, username, password, basepath, filepath, newName, uploadFile.getInputStream());
			
			if(!result){
				uploadImageResult.setError(1);
				uploadImageResult.setMassage("文件上传失败");;
				return uploadImageResult;
			}
			
			uploadImageResult.setError(0);
			uploadImageResult.setUrl(image_base_url+"/"+filepath+"/"+newName);
			return uploadImageResult;
			//
		} catch (IOException e) {
			uploadImageResult.setError(1);
			uploadImageResult.setMassage("文件上传发生异常");;
			return uploadImageResult;
		}
		
	}

}
