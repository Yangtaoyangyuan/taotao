package com.yt.service.Impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yt.common.pojo.ItemCatNodeOfTree;
import com.yt.mapper.TbItemCatMapper;
import com.yt.pojo.TbItemCat;
import com.yt.pojo.TbItemCatExample;
import com.yt.pojo.TbItemCatExample.Criteria;
import com.yt.service.ItemCatService;

@Service
public class ItemCatServiceImpl implements ItemCatService {
	
	@Autowired
	private TbItemCatMapper tbItemCatMapper;

	/**
	 * 实现树形结构图。
	 */
	@Override
	public List<ItemCatNodeOfTree> getItemClass(long parentid) {
		// TODO Auto-generated method stub
		List<ItemCatNodeOfTree> CatList = new ArrayList<ItemCatNodeOfTree>();
		
		TbItemCatExample example = new TbItemCatExample();
		Criteria criteria = example.createCriteria();
		criteria.andParentIdEqualTo(parentid);
		List<TbItemCat> list = tbItemCatMapper.selectByExample(example );
		for(TbItemCat itemCat : list){
			
			ItemCatNodeOfTree Node = new ItemCatNodeOfTree();
			
			Node.setId(itemCat.getId());
			Node.setText(itemCat.getName());
			Node.setState(itemCat.getIsParent()?"closed":"open");
			
			CatList.add(Node);
		}
		return CatList;
	}

}
