package com.yt.service;

import java.util.List;

import com.yt.common.Utils.TaotaoResult;
import com.yt.common.pojo.ItemCatNodeOfTree;

public interface ContentCategoryService {

	/**
	 * 生成商品分类管理树形图。
	 * @param parentId 父节点id,默认为0，即第一层
	 * @return 查询的结果集合
	 */
	List<ItemCatNodeOfTree> getCategoryList(long parentId);
	
	/**
	 * 新增一个商品分类节点，添加到数据库
	 * @param parentId 新增节点的父节点Id
	 * @param name 新增节点的名字
	 * @return TaotaoResult对象
	 */
	TaotaoResult insertContentCategory(long parentId, String name);
	
	/**
	 * 删除商品分类管理中的某个节点。
	 * @param parentId 要上出节点的父节点id
	 * @param id 要删除节点的id
	 * @return TaotaoResult
	 */
	TaotaoResult deleteContentCategory(long id);
	
	/**
	 * 更改商品分类管理的某个节点的名字，即重命名
	 * @param id 待更改节点的id
	 * @param name 更改节点名字为name
	 * @return TaotaoResult
	 */
	TaotaoResult updateContentCategory(long id, String name);
}
