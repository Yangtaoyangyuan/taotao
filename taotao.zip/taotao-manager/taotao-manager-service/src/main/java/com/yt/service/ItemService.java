package com.yt.service;

import com.yt.common.Utils.TaotaoResult;
import com.yt.common.pojo.EUDateGridResult;
import com.yt.pojo.TbItem;

public interface ItemService {
	
	public TbItem getItemById(long ItemId);
	
	public EUDateGridResult getItemList(int page,int rows);
	
	public TaotaoResult createItem(TbItem item,String desc,String itemParams) throws Exception;
}
