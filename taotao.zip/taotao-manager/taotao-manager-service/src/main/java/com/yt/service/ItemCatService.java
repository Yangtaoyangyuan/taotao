package com.yt.service;

import java.util.List;
import com.yt.common.pojo.ItemCatNodeOfTree;

public interface ItemCatService {
	
	public List<ItemCatNodeOfTree> getItemClass(long parentid);

}
