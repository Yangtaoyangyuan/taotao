package com.yt.service.Impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yt.common.Utils.TaotaoResult;
import com.yt.mapper.TbItemParamMapper;
import com.yt.pojo.TbItemParam;
import com.yt.pojo.TbItemParamExample;
import com.yt.pojo.TbItemParamExample.Criteria;
import com.yt.service.ItemParamService;

/**
 * 商品的规格参数模板
 * @author YT
 *
 */
@Service
public class ItemParamServiceImpl implements ItemParamService {

	@Autowired
	private TbItemParamMapper itemParamMapper;
	
	
	/**
	 * 查询某类商品的规格参数模板是否存在与数据库中
	 */
	@Override
	public TaotaoResult getItemParamByCid(long cid) {
		TbItemParamExample example = new TbItemParamExample();
		Criteria criteria = example.createCriteria();
		criteria.andItemCatIdEqualTo(cid);
		List<TbItemParam> list = itemParamMapper.selectByExampleWithBLOBs(example);
		//判断是否查询到结果
		if(list != null && list.size() > 0){
			return TaotaoResult.ok(list.get(0));
		}
		return TaotaoResult.ok();
	}

	/**
	 * 插入某类商品规格参数模板，即向商品规格信息模板数据库中新添一个某类商品的规格参数信息模板
	 */
	@Override
	public TaotaoResult insertItemParam(TbItemParam itemParam) {
		//补全pojo
		itemParam.setCreated(new Date());
		itemParam.setUpdated(new Date());
		
		//插入到规格参数模板数据库
		itemParamMapper.insert(itemParam);
		return TaotaoResult.ok();
	}

	

}
