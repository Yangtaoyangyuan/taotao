package com.yt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.yt.common.Utils.JsonUtils;
import com.yt.common.pojo.UploadImageResult;
import com.yt.service.ImageService;

@Controller
public class PictureController {
	
	@Autowired
	private ImageService imageService;
	
	@ResponseBody
	@RequestMapping("/pic/upload")
	public String pictureUpload(MultipartFile uploadFile){
		UploadImageResult result = imageService.UploadImage(uploadFile);
		//为了保证流浪器的兼容性，需要将result转换成json格式的字符串,利用工具类实现
		String json = JsonUtils.objectToJson(result);
		
		return json;
	}

}
