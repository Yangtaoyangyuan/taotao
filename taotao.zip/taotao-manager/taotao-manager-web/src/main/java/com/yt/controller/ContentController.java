package com.yt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.yt.common.Utils.TaotaoResult;
import com.yt.common.pojo.EUDateGridResult;
import com.yt.pojo.TbContent;
import com.yt.service.ContentService;

@Controller
@RequestMapping("/content")
public class ContentController {

	@Autowired
	private ContentService contentService;
	
	/**
	 * 根据内容分类管理的某类广告id去内容管理数据库中查询相应广告信息，并返回分页显示
	 * @param CtaegoryId 某类广告的id
	 * @param page 多少页
	 * @param rows 每页多少条信息
	 * @return EUDateGridResult
	 */
	@RequestMapping("/query/list")
	@ResponseBody
	public EUDateGridResult getContent(long categoryId, int page, int rows){
		EUDateGridResult result = contentService.getContent(categoryId, page, rows);
		return result;
	}
	
	@RequestMapping("/save")
	@ResponseBody
	public TaotaoResult insertContent(TbContent tbContent){
		TaotaoResult result = contentService.insertContent(tbContent);
		return result;
	}
}
