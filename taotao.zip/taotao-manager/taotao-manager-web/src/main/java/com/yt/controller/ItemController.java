package com.yt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.yt.common.Utils.TaotaoResult;
import com.yt.common.pojo.EUDateGridResult;
import com.yt.pojo.TbItem;
import com.yt.service.ItemService;

@Controller
@RequestMapping("/item")
public class ItemController {
	
	@Autowired
	private ItemService itemService;
	
	@ResponseBody
	@RequestMapping("/{itemId}")
	public TbItem getItemById(@PathVariable Long itemId){
		return itemService.getItemById(itemId);
	}
	
	@ResponseBody
	@RequestMapping("/list")
	public EUDateGridResult getItemList(int page,int rows){
		
		EUDateGridResult dateGridResult = itemService.getItemList(page, rows);
		return dateGridResult;
	}
	
	@RequestMapping(value="/save", method=RequestMethod.POST)
	@ResponseBody
	public TaotaoResult createItem(TbItem item, String desc, String itemParams) throws Exception{//利用参数绑定，必须保证pojo中的TbItem对象的各个属性名与表当传递的参数名一致
		TaotaoResult result = itemService.createItem(item,desc,itemParams);
		return result;
	}

}
