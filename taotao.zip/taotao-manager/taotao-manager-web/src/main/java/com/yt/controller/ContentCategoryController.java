package com.yt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.yt.common.Utils.TaotaoResult;
import com.yt.common.pojo.ItemCatNodeOfTree;
import com.yt.service.ContentCategoryService;

@Controller
@RequestMapping("/content/category")
public class ContentCategoryController {

	@Autowired
	private ContentCategoryService contentCategoryService;
	
	/**
	 * 生成商品分类树形图
	 * @param parentId
	 * @return
	 */
	@RequestMapping("/list")
	@ResponseBody
	public List<ItemCatNodeOfTree> getContentCategoryList(@RequestParam(value="id", defaultValue="0")long parentId){
		List<ItemCatNodeOfTree> list = contentCategoryService.getCategoryList(parentId);
		return list;
	}
	
	/**
	 * 新增一个商品分类节点，添加到数据库
	 * @param parentId 新增节点的父节点Id
	 * @param name 新增节点的名字
	 * @return TaotaoResult对象
	 */
	@RequestMapping("/create")
	@ResponseBody
	public TaotaoResult insertContentCategory(long parentId, String name){
		TaotaoResult result = contentCategoryService.insertContentCategory(parentId, name);
		return result;
	}
	
	/**
	 * 删除商品分类管理中的某个节点。
	 * @param parentId 要上出节点的父节点id
	 * @param id 要删除节点的id
	 * @return TaotaoResult
	 */
	@RequestMapping("/delete")
	@ResponseBody
	public TaotaoResult deleteContentCategory(long id){
		TaotaoResult result = contentCategoryService.deleteContentCategory(id);
		return result;
	}
	
	/**
	 * 更改商品分类管理的某个节点的名字，即重命名
	 * @param id 待更改节点的id
	 * @param name 更改节点名字为name
	 * @return TaotaoResult
	 */
	@RequestMapping("/update")
	@ResponseBody
	public TaotaoResult updateContentCategory(long id, String name){
		TaotaoResult result = contentCategoryService.updateContentCategory(id, name);
		return result;
	}
	
}
